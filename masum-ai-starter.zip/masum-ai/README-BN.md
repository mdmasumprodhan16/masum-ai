# Masum AI — বাংলা AI Question–Answer Website

এই প্রজেক্টে আছে:
- মোবাইল/iPhone-এ ব্যবহারযোগ্য বাংলা ওয়েব পেজ
- `/api/answer` নামের সার্ভার-সাইড endpoint
- Cloudflare Workers AI binding ব্যবহার করে উত্তর তৈরি
- API key বা গোপন টোকেন ওয়েব পেজে রাখা হয় না

## বিনামূল্যে চালুর পথ

### ১. Cloudflare অ্যাকাউন্ট
1. iPhone-এর Safari থেকে https://dash.cloudflare.com/ খুলে অ্যাকাউন্ট তৈরি/লগইন করো।
2. Workers & Pages-এ গিয়ে নতুন Pages project তৈরি করো।
3. এই ফোল্ডারটি GitHub repository-তে আপলোড করে Pages-এ GitHub repository সংযুক্ত করো। Pages Functions ব্যবহারের জন্য Git integration বা Wrangler deployment দরকার; শুধু static Direct Upload যথেষ্ট নয়।

### ২. ফাইলগুলো GitHub-এ আপলোড
এই ZIP extract করে `index.html`, `functions/api/answer.js`, এবং `README-BN.md` repository-র root-এ রাখো। ফোল্ডারের নাম ঠিক এভাবে থাকবে:
- `index.html`
- `functions/api/answer.js`

Cloudflare Pages build settings-এ framework preset `None` নির্বাচন করো। Build command খালি রাখো এবং output directory হিসেবে `.` দাও, যদি dashboard সেটি গ্রহণ করে। যদি সেটআপে build output directory চাওয়া হয়, Cloudflare-এর বর্তমান Pages নির্দেশনা অনুসরণ করো।

### ৩. Workers AI binding যোগ
1. Cloudflare Dashboard → Workers & Pages → তোমার Pages project।
2. Settings → Bindings (কিছু UI-তে Settings → Functions → Bindings)।
3. Add binding → Workers AI নির্বাচন করো।
4. Variable/binding name অবশ্যই `AI` দাও।
5. Save করে নতুন deployment করো।

Cloudflare Workers AI-এর ফ্রি ব্যবহারের দৈনিক সীমা থাকে এবং সীমা/মডেল availability পরিবর্তিত হতে পারে। বর্তমান সীমা দেখো:
https://developers.cloudflare.com/workers-ai/platform/pricing/

### ৪. পরীক্ষা
Deployment সফল হলে Cloudflare-এর দেওয়া `https://...pages.dev` ঠিকানা খোলো। “বাংলাদেশের জাতীয় ফুল কী?” লিখে “উত্তর তৈরি করুন” চাপো।

## নিরাপত্তা
- কোনো API key, password বা secret `index.html`-এ লিখবে না।
- ব্যক্তিগত/সংবেদনশীল তথ্য প্রশ্নে পাঠিও না।
- এই starter version-এ লগইন, per-user quota বা advanced abuse protection নেই। পাবলিকভাবে শেয়ার করার আগে rate limiting/abuse protection যোগ করো।
- AI ভুল উত্তর দিতে পারে; গুরুত্বপূর্ণ তথ্য যাচাই করো।
- এই সাইট TikTok-এর comment inbox পড়ে না এবং TikTok-এ নিজে থেকে উত্তর পোস্ট করে না।

## সমস্যা হলে
- `AI binding সেট করা হয়নি`: binding-এর নাম `AI` কিনা দেখো, তারপর redeploy করো।
- 404 `/api/answer`: `functions/api/answer.js` সঠিক ফোল্ডারে আছে কিনা দেখো এবং Pages Functions deployment ব্যবহার করো।
- AI model error: Cloudflare Workers AI dashboard-এ account/model availability এবং current model name যাচাই করো।
